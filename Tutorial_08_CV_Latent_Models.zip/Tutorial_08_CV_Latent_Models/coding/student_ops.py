"""Optional script-based starter. The notebooks offer the same four TODOs."""
import torch
import torch.nn.functional as F

def sample_latent(mu,logvar,eps=None):
    if eps is None: eps=torch.randn_like(mu)
    # TODO A: logvar is log variance, not log standard deviation.
    raise NotImplementedError('Implement reparameterization.')

def kl_diag(mu,logvar):
    # TODO B1: return shape [batch], summing latent dimensions.
    raise NotImplementedError('Implement diagonal-Gaussian KL to N(0,I).')

def per_image_bce(logits,targets):
    # TODO B2: return shape [batch], summing channel/height/width.
    raise NotImplementedError('Implement per-image reconstruction NLL.')

def masked_bce(logits,targets,observed_mask):
    # TODO C: only observed pixels contribute to the inference objective.
    raise NotImplementedError('Implement observed-pixel reconstruction NLL.')
