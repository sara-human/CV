"""Lab C: frozen-decoder local variational inference and image completion."""
from pathlib import Path
import json,time
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from vision_lab import ROOT,setup,load_data,load_model,image_grid,check_ops

def make_mask(x):
    mask=torch.ones_like(x); mask[:,:,8:20,8:20]=0
    return mask

def objective(model,observed,mask,mu,lv,ops,eps):
    k,b,_=eps.shape
    z=ops.sample_latent(mu.unsqueeze(0),lv.unsqueeze(0),eps)
    logits=model.decode(z.reshape(-1,model.latent_dim))
    obs=observed.unsqueeze(0).expand(k,-1,-1,-1,-1).reshape(-1,1,28,28)
    masks=mask.unsqueeze(0).expand(k,-1,-1,-1,-1).reshape(-1,1,28,28)
    rec=ops.masked_bce(logits,obs,masks).reshape(k,b).mean(0)
    return rec+ops.kl_diag(mu,lv)

def refine(model,observed,mask,ops,steps=100,seed=901):
    """Receives NO hidden ground truth. Model weights are frozen, local q is trained."""
    device=observed.device; b=len(observed)
    original_flags=[p.requires_grad for p in model.parameters()]
    for p in model.parameters(): p.requires_grad_(False)
    try:
        with torch.no_grad(): start_mu,start_lv=model.encode(observed)
        mu=torch.nn.Parameter(start_mu.detach().clone()); lv=torch.nn.Parameter(start_lv.detach().clone())
        optimizer=torch.optim.Adam([mu,lv],lr=.045)
        generator=torch.Generator(device=device).manual_seed(seed)
        selection_noise=torch.randn(64,b,model.latent_dim,generator=generator,device=device)
        with torch.no_grad(): best_score=objective(model,observed,mask,mu,lv,ops,selection_noise)
        best_mu=mu.detach().clone(); best_lv=lv.detach().clone(); history=[float(best_score.mean())]
        start=time.perf_counter()
        for step in range(steps):
            eps=torch.randn(8,b,model.latent_dim,generator=generator,device=device)
            loss=objective(model,observed,mask,mu,lv,ops,eps).mean()
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            with torch.no_grad(): lv.clamp_(-8,6)
            if (step+1)%10==0 or step==steps-1:
                with torch.no_grad():
                    candidate=objective(model,observed,mask,mu,lv,ops,selection_noise)
                    better=candidate<best_score
                    best_score=torch.where(better,candidate,best_score)
                    best_mu=torch.where(better[:,None],mu,best_mu); best_lv=torch.where(better[:,None],lv,best_lv)
                    history.append(float(best_score.mean()))
        elapsed=time.perf_counter()-start
        # Independent evaluation noise avoids reporting the selected finite-MC objective as exact.
        eval_noise=torch.randn(256,b,model.latent_dim,generator=generator,device=device)
        with torch.no_grad():
            initial=objective(model,observed,mask,start_mu,start_lv,ops,eval_noise)
            final=objective(model,observed,mask,best_mu,best_lv,ops,eval_noise)
        return {'mu':best_mu.detach(),'logvar':best_lv.detach(),'initial_mu':start_mu.detach(),'initial_logvar':start_lv.detach(),
                'initial_mc_negative_elbo':initial.cpu().tolist(),'refined_mc_negative_elbo':final.cpu().tolist(),
                'seconds':elapsed,'selection_history':history}
    finally:
        for p,flag in zip(model.parameters(),original_flags): p.requires_grad_(flag)

@torch.no_grad()
def posterior_prediction(model,mu,lv,ops,samples=128,seed=995):
    g=torch.Generator(device=mu.device).manual_seed(seed)
    eps=torch.randn(samples,len(mu),model.latent_dim,generator=g,device=mu.device)
    z=ops.sample_latent(mu.unsqueeze(0),lv.unsqueeze(0),eps)
    probs=model.decode(z.reshape(-1,model.latent_dim)).sigmoid().reshape(samples,len(mu),1,28,28)
    # Var_z E[X|z] measures variation in component means; pbar*(1-pbar) includes pixel noise.
    return probs.mean(0),probs.var(0,unbiased=False),probs[:3]

def run(ops,checkpoint=None,outdir=None,steps=100,device='cpu'):
    setup(); check_ops(ops,True)
    outdir=Path(outdir or ROOT/'outputs'/'lab_c'); outdir.mkdir(parents=True,exist_ok=True)
    data=load_data(); model=load_model(checkpoint,device)
    # First examples, selected before looking at completion quality.
    truth=data['test'][0][:12].to(device); mask=make_mask(truth)
    observed=truth*mask+.5*(1-mask)
    before={k:v.detach().clone() for k,v in model.state_dict().items()}
    completion=refine(model,observed,mask,ops,steps)
    for k,v in model.state_dict().items(): torch.testing.assert_close(v,before[k])
    init,_,_=posterior_prediction(model,completion['initial_mu'],completion['initial_logvar'],ops)
    pred,mean_var,sample_probs=posterior_prediction(model,completion['mu'],completion['logvar'],ops)
    # Hidden ground truth is introduced ONLY here, for evaluation and figures.
    hidden=1-mask
    train_mean=data['train'][0].mean(0,keepdim=True).to(device).expand_as(truth)
    def hidden_metrics(probs):
        bce=F.binary_cross_entropy(probs.clamp(1e-6,1-1e-6),truth,reduction='none')
        return {'missing_pixel_bce':float((bce*hidden).sum()/hidden.sum()),
                'missing_pixel_brier':float(((probs-truth).square()*hidden).sum()/hidden.sum())}
    full=refine(model,truth,torch.ones_like(truth),ops,steps=60,seed=103)
    model.eval()
    with torch.no_grad():
        for _ in range(5): model.encode(truth)
        start=time.perf_counter()
        for _ in range(50): model.encode(truth)
        encoder_seconds=(time.perf_counter()-start)/50
    image_grid([truth[:8],observed[:8],(truth*mask+init*hidden)[:8],(truth*mask+pred*hidden)[:8]],
               ['Ground truth','Observed only','Encoder init','Local VI mean'],outdir/'inpainting.png',
               'Image completion: hidden pixels never enter the optimization objective')
    rows=[observed[:6],(truth*mask+pred*hidden)[:6]]+[ (truth*mask+s*hidden)[:6] for s in sample_probs]
    image_grid(rows,['Observed','Posterior mean','Latent draw 1','Latent draw 2','Latent draw 3'],outdir/'completion_diversity.png',
               'Decoder probabilities for different latent draws (approximate model uncertainty)')
    fig,axes=plt.subplots(1,2,figsize=(9,3.4))
    axes[0].plot(range(0,len(completion['selection_history'])*10,10),completion['selection_history'],'o-')
    axes[0].set(xlabel='Local optimization steps (checkpoints)',ylabel='Observed-pixel MC negative ELBO',title='Optimize only what is observed')
    axes[1].bar(['Encoder q(x)','Locally refined q'],[sum(full['initial_mc_negative_elbo'])/len(truth),sum(full['refined_mc_negative_elbo'])/len(truth)],color=['#008c95','#e49535'])
    axes[1].set(ylabel='Full-image MC negative ELBO',title='Same frozen decoder; different inference')
    fig.tight_layout(); fig.savefig(outdir/'inference_comparison.png',dpi=170); plt.close(fig)
    result={'test_images':len(truth),'mask':'center 12x12, 1=observed','optimization_steps':steps,
            'inpainting':{'train_pixel_mean_baseline':hidden_metrics(train_mean),'encoder_initialization':hidden_metrics(init),'local_vi':hidden_metrics(pred)},
            'full_image_inference':{'encoder_mc_negative_elbo':sum(full['initial_mc_negative_elbo'])/len(truth),
                                    'refined_mc_negative_elbo':sum(full['refined_mc_negative_elbo'])/len(truth),
                                    'encoder_batch_seconds':encoder_seconds,'local_refinement_seconds':full['seconds']},
            'completion_observed_objective':{'initial_mean':sum(completion['initial_mc_negative_elbo'])/len(truth),
                                             'refined_mean':sum(completion['refined_mc_negative_elbo'])/len(truth)},
            'notes':['Inference timings exclude shared model training; small CPU example, not a hardware benchmark.',
                     'ELBO values are finite-MC estimates; local optimization is not guaranteed to reach the global optimum.',
                     'Missing pixels are evaluated only after inference; lower observed loss need not improve hidden pixels.',
                     'Prediction uses a single diagonal Gaussian q; it may miss multiple plausible completions.']}
    (outdir/'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    torch.save({'observed':observed.cpu(),'mask':mask.cpu(),'prediction':pred.cpu(),'latent_mean_variance':mean_var.cpu()},outdir/'completion_tensors.pt')
    print(json.dumps(result,indent=2),flush=True)
    return result

if __name__=='__main__':
    import argparse, importlib
    parser=argparse.ArgumentParser()
    parser.add_argument('--module',default='student_ops',help='Module containing the completed functions.')
    run(importlib.import_module(parser.parse_args().module))
