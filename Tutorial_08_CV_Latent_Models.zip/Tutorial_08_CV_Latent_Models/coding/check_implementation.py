"""Quick mathematical checks, e.g. python coding/check_implementation.py --module student_ops."""
import argparse,importlib,json,math
import torch
from vision_lab import check_ops,load_data,load_model

def main(module):
    ops=importlib.import_module(module)
    print(check_ops(ops,include_mask=True))
    mu=torch.tensor([.5,-.5],dtype=torch.float64,requires_grad=True)
    lv=torch.tensor([math.log(.25),math.log(4.)],dtype=torch.float64,requires_grad=True)
    eps=torch.tensor([1.,-.5],dtype=torch.float64)
    z=ops.sample_latent(mu,lv,eps);a=torch.tensor([2.,-1.],dtype=torch.float64)
    r=.5*(a@z-1).square(); gm,gl=torch.autograd.grad(r,(mu,lv))
    torch.testing.assert_close(z,torch.tensor([1.,-1.5],dtype=torch.float64))
    torch.testing.assert_close(gm,torch.tensor([5.,-2.5],dtype=torch.float64))
    torch.testing.assert_close(gl,torch.tensor([1.25,1.25],dtype=torch.float64))
    data=load_data()
    assert all(set(x.unique().tolist())<={0.,1.} for x,_ in data.values())
    model=load_model()
    with torch.no_grad():
        m,l=model.encode(data['test'][0][:2]);out=model.decode(m)
    assert m.shape==(2,8) and out.shape==(2,1,28,28)
    result={'exercise_1_reconstruction':-sum(math.log(v) for v in [.8,.8,.6,.9]),
            'exercise_1_kl':.5*(1+.25-1-math.log(.25)),'exercise_2_loss':r.item(),
            'exercise_2_grad_mu':gm.tolist(),'exercise_2_grad_logvar':gl.tolist(),
            'exercise_3_local_parameter_MB':2*60000*8*4/1e6,
            'exercise_4_mc_negative_elbo':-math.log(.8)-math.log(.7)+.4,'status':'passed'}
    print(json.dumps(result,indent=2));return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--module',default='student_ops');args=p.parse_args();main(args.module)
