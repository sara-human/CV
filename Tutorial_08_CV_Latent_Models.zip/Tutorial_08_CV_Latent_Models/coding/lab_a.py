"""Lab A: differentiate an image reconstruction loss through Gaussian sampling."""
import json
from pathlib import Path
import torch
import matplotlib.pyplot as plt
from vision_lab import ROOT,setup,image_grid

def blob(z,gain):
    axis=torch.linspace(-1,1,16,dtype=z.dtype,device=z.device)
    yy,xx=torch.meshgrid(axis,axis,indexing='ij')
    return gain.sigmoid()*torch.exp(-((xx-z[...,0,None,None])**2+(yy-z[...,1,None,None])**2)/.16)

def run(ops,outdir=None):
    setup(); outdir=Path(outdir or ROOT/'outputs'/'lab_a'); outdir.mkdir(parents=True,exist_ok=True)
    target=blob(torch.tensor([.35,-.25],dtype=torch.float64),torch.tensor(2.,dtype=torch.float64))
    results={}
    for method in ['sample','rsample','manual']:
        torch.manual_seed(77)
        mu=torch.tensor([-.3,.2],dtype=torch.float64,requires_grad=True)
        lv=torch.tensor([-3.,-3.],dtype=torch.float64,requires_grad=True)
        gain=torch.tensor(2.,dtype=torch.float64,requires_grad=True)
        q=torch.distributions.Normal(mu,torch.exp(.5*lv))
        if method=='sample': z=q.sample((16,))
        elif method=='rsample': z=q.rsample((16,))
        else: z=ops.sample_latent(mu,lv,torch.randn(16,2,dtype=mu.dtype))
        loss=(blob(z,gain)-target).square().flatten(1).sum(1).mean()
        loss.backward()
        results[method]={'loss':loss.item(),'mu_gradient':None if mu.grad is None else mu.grad.tolist(),
                         'logvar_gradient':None if lv.grad is None else lv.grad.tolist(),'decoder_gain_gradient':gain.grad.item()}
    # Same random numbers on both sides of each finite difference.
    mu=torch.tensor([-.3,.2],dtype=torch.float64,requires_grad=True)
    lv=torch.tensor([-3.,-3.],dtype=torch.float64,requires_grad=True)
    eps=torch.randn(32,2,dtype=torch.float64,generator=torch.Generator().manual_seed(34))
    def objective(m,l): return (blob(ops.sample_latent(m,l,eps),torch.tensor(2.))-target).square().flatten(1).sum(1).mean()
    grad=torch.cat(torch.autograd.grad(objective(mu,lv),(mu,lv)))
    fd=[]; h=1e-5
    for index in range(4):
        mp,mm=mu.detach().clone(),mu.detach().clone(); lp,lm=lv.detach().clone(),lv.detach().clone()
        if index<2: mp[index]+=h; mm[index]-=h
        else: lp[index-2]+=h; lm[index-2]-=h
        fd.append(((objective(mp,lp)-objective(mm,lm))/(2*h)).item())
    torch.testing.assert_close(grad,torch.tensor(fd,dtype=grad.dtype),atol=1e-6,rtol=1e-5)
    results['finite_difference']={'autograd':grad.tolist(),'central_difference':fd,'max_absolute_error':float((grad-torch.tensor(fd,dtype=grad.dtype)).abs().max())}
    assert results['sample']['mu_gradient'] is None
    assert results['rsample']['mu_gradient'] is not None
    torch.testing.assert_close(torch.tensor(results['manual']['mu_gradient']),torch.tensor(results['rsample']['mu_gradient']))
    # Visually optimize only the latent mean; variance stays fixed.
    initial=mu.detach().clone(); mean=torch.nn.Parameter(initial.clone())
    opt=torch.optim.Adam([mean],lr=.035)
    losses=[]
    for _ in range(80):
        loss=objective(mean,lv.detach()); opt.zero_grad(); loss.backward(); opt.step(); losses.append(loss.item())
    predicted=torch.stack([target,blob(initial,torch.tensor(2.)),blob(mean.detach(),torch.tensor(2.))])
    image_grid([predicted],['Intensity'],outdir/'blob_alignment.png','Lab A: reconstructing an image by moving a latent center',['Target','Initial center','After optimization'])
    fig,axes=plt.subplots(1,2,figsize=(9,3.4))
    axes[0].plot(losses); axes[0].set(xlabel='Optimization step',ylabel='MC image squared error',title='A differentiable sampling path')
    axes[1].bar(torch.arange(4).numpy()-.18,grad.numpy(),width=.35,label='Autograd')
    axes[1].bar(torch.arange(4).numpy()+.18,fd,width=.35,label='Fixed-noise finite difference')
    axes[1].set_xticks(range(4),['mu_x','mu_y','logvar_x','logvar_y']); axes[1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(outdir/'gradient_check.png',dpi=170); plt.close(fig)
    results['optimized_center']=mean.detach().tolist()
    (outdir/'metrics.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print(json.dumps(results,indent=2),flush=True)
    return results

if __name__=='__main__':
    import argparse, importlib
    parser=argparse.ArgumentParser()
    parser.add_argument('--module',default='student_ops',help='Module containing the completed functions.')
    run(importlib.import_module(parser.parse_args().module))
