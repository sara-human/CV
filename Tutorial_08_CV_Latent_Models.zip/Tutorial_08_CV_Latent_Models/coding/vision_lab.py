"""Shared image/data/model scaffolding. Mathematical TODOs are passed in as ops."""
from pathlib import Path
import copy, csv, json, random, time
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SEED=4186

def setup(seed=SEED,threads=2):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.set_num_threads(threads)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def load_data():
    path=ROOT/'data'/'mnist_binary_subset.npz'
    if not path.exists(): raise FileNotFoundError('Run: python coding/prepare_data.py')
    with np.load(path) as f:
        return {split:(torch.from_numpy(f['x_'+split].copy()).float().unsqueeze(1),
                       torch.from_numpy(f['y_'+split].astype(np.int64))) for split in ['train','val','test']}

class ConvVAE(nn.Module):
    def __init__(self,latent_dim=8):
        super().__init__(); self.latent_dim=latent_dim
        self.encoder=nn.Sequential(nn.Conv2d(1,16,4,2,1),nn.ReLU(),
            nn.Conv2d(16,32,4,2,1),nn.ReLU(),nn.Flatten(),nn.Linear(32*7*7,64),nn.ReLU())
        self.mu=nn.Linear(64,latent_dim); self.logvar=nn.Linear(64,latent_dim)
        self.decoder_input=nn.Sequential(nn.Linear(latent_dim,64),nn.ReLU(),nn.Linear(64,32*7*7),nn.ReLU())
        self.decoder=nn.Sequential(nn.ConvTranspose2d(32,16,4,2,1),nn.ReLU(),nn.ConvTranspose2d(16,1,4,2,1))
    def encode(self,x):
        h=self.encoder(x)
        return self.mu(h),self.logvar(h).clamp(-8,6)
    def decode(self,z):
        return self.decoder(self.decoder_input(z).reshape(-1,32,7,7))

def check_ops(ops,include_mask=False):
    mu=torch.tensor([[1.,0.]],dtype=torch.float64,requires_grad=True)
    lv=torch.tensor([[np.log(.25),0.]],dtype=torch.float64,requires_grad=True)
    eps=torch.ones_like(mu)
    z=ops.sample_latent(mu,lv,eps)
    torch.testing.assert_close(z,torch.tensor([[1.5,1.]],dtype=torch.float64))
    gm,gl=torch.autograd.grad(z.sum(),(mu,lv))
    torch.testing.assert_close(gm,torch.ones_like(mu))
    torch.testing.assert_close(gl,torch.tensor([[.25,.5]],dtype=torch.float64))
    torch.testing.assert_close(ops.kl_diag(torch.zeros_like(mu),torch.zeros_like(mu)),torch.zeros(1,dtype=mu.dtype))
    torch.testing.assert_close(ops.kl_diag(mu,lv),torch.tensor([.8181471805599453],dtype=mu.dtype))
    logits=torch.zeros(2,1,2,2,dtype=torch.float64,requires_grad=True)
    x=torch.tensor([[[[1.,0.],[1.,0.]]]]).double().expand(2,-1,-1,-1)
    loss=ops.per_image_bce(logits,x)
    assert loss.shape==(2,), 'Return one NLL per image.'
    torch.testing.assert_close(loss,torch.full((2,),4*np.log(2),dtype=torch.float64))
    if include_mask:
        mask=torch.tensor([[[[1.,0.],[1.,0.]]]],dtype=torch.float64)
        masked=ops.masked_bce(logits,x,mask)
        torch.testing.assert_close(masked,torch.full((2,),2*np.log(2),dtype=torch.float64))
        grad=torch.autograd.grad(masked.sum(),logits)[0]
        assert torch.count_nonzero(grad*(1-mask))==0, 'Hidden pixels must have zero likelihood gradient.'
        altered=x*mask+(1-x)*(1-mask)
        torch.testing.assert_close(masked,ops.masked_bce(logits,altered,mask))
    return 'Passed: reparameterization gradients, KL identity, image reduction'+(', hidden-pixel invariance.' if include_mask else '.')

@torch.no_grad()
def evaluate(model,x,ops,samples=4,batch_size=128,seed=724):
    model.eval(); device=next(model.parameters()).device
    generator=torch.Generator(device=device).manual_seed(seed)
    totals=np.zeros(3)
    for xb in x.split(batch_size):
        xb=xb.to(device); mu,lv=model.encode(xb)
        b=len(xb)
        eps=torch.randn(samples,b,model.latent_dim,generator=generator,device=device)
        z=ops.sample_latent(mu.unsqueeze(0),lv.unsqueeze(0),eps)
        logits=model.decode(z.reshape(-1,model.latent_dim))
        rec=ops.per_image_bce(logits,xb.unsqueeze(0).expand(samples,-1,-1,-1,-1).reshape(-1,1,28,28)).reshape(samples,b).mean(0)
        kl=ops.kl_diag(mu,lv)
        totals+=np.array([rec.sum().item(),kl.sum().item(),(rec+kl).sum().item()])
    return dict(zip(['reconstruction_nats_per_image','kl_nats_per_image','negative_elbo_nats_per_image'],(totals/len(x)).tolist()))

def image_grid(rows,row_labels,path,title='',column_labels=None):
    rows=[r.detach().cpu().numpy() if torch.is_tensor(r) else np.asarray(r) for r in rows]
    n=len(rows[0]); fig,axes=plt.subplots(len(rows),n,figsize=(1.22*n,1.5*len(rows)),squeeze=False)
    for i,row in enumerate(rows):
        for j,img in enumerate(row):
            axes[i,j].imshow(np.squeeze(img),cmap='gray',vmin=0,vmax=1,interpolation='nearest')
            axes[i,j].set_xticks([]); axes[i,j].set_yticks([])
            if j==0: axes[i,j].set_ylabel(row_labels[i],fontsize=9)
            if i==0 and column_labels: axes[i,j].set_title(str(column_labels[j]),fontsize=10)
    fig.suptitle(title,fontsize=13); fig.tight_layout()
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(path,dpi=170,bbox_inches='tight'); plt.close(fig)

@torch.no_grad()
def visual_report(model,data,outdir):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    device=next(model.parameters()).device
    x,labels=data['test']; xb=x[:8].to(device)
    mu,lv=model.encode(xb); mean_z_recon=model.decode(mu).sigmoid()
    image_grid([xb,mean_z_recon],['Held-out input','Decode mean z'],outdir/'reconstructions.png',
               'Held-out reconstruction: decoder probabilities, not sampled binary pixels',labels[:8].tolist())
    generator=torch.Generator(device=device).manual_seed(391)
    z=torch.randn(8,model.latent_dim,generator=generator,device=device)
    probs=model.decode(z).sigmoid()
    draws=torch.bernoulli(probs,generator=generator)
    image_grid([probs,draws],['Decoder mean','Binary draw'],outdir/'prior_samples.png','Prior generation: z ~ N(0,I), then x ~ Bernoulli(decoder(z))')
    endpoints=[0,int(torch.nonzero(labels!=labels[0])[0].item())]
    endpoints_mu,_=model.encode(x[endpoints].to(device))
    t=torch.linspace(0,1,8,device=device).unsqueeze(1)
    z=(1-t)*endpoints_mu[0]+t*endpoints_mu[1]
    image_grid([model.decode(z).sigmoid()],['Decoder mean'],outdir/'latent_interpolation.png',
               'Interpolation between two encoded images (not a density or accuracy guarantee)')
    all_mu=torch.cat([model.encode(b.to(device))[0].cpu() for b in x.split(128)])
    centered=all_mu-all_mu.mean(0)
    _,_,v=torch.linalg.svd(centered,full_matrices=False)
    projected=(centered@v[:2].T).numpy()
    fig,ax=plt.subplots(figsize=(6,4.5)); sc=ax.scatter(projected[:,0],projected[:,1],c=labels.numpy(),cmap='tab10',s=8,alpha=.7)
    fig.colorbar(sc,ax=ax,ticks=range(10),label='Digit label (analysis only)')
    ax.set(xlabel='PC1 of posterior means',ylabel='PC2 of posterior means',title='A 2D projection of the learned 8D representation')
    fig.tight_layout(); fig.savefig(outdir/'latent_projection.png',dpi=170); plt.close(fig)

def train_vae(ops,epochs=12,latent_dim=8,device='cpu',outdir=None,max_train=None):
    setup(); check_ops(ops)
    outdir=Path(outdir or ROOT/'outputs'/'lab_b'); outdir.mkdir(parents=True,exist_ok=True)
    data=load_data(); x_train=data['train'][0]
    if max_train: x_train=x_train[:max_train]
    loader=DataLoader(TensorDataset(x_train),batch_size=128,shuffle=True,num_workers=0,
                      generator=torch.Generator().manual_seed(SEED))
    model=ConvVAE(latent_dim).to(device)
    optimizer=torch.optim.Adam(model.parameters(),lr=1e-3)
    initial=evaluate(model,data['val'][0],ops)
    best=float('inf'); history=[]; start=time.perf_counter()
    for epoch in range(1,epochs+1):
        model.train(); running=0
        for (x,) in loader:
            x=x.to(device); mu,lv=model.encode(x)
            logits=model.decode(ops.sample_latent(mu,lv))
            loss=(ops.per_image_bce(logits,x)+ops.kl_diag(mu,lv)).mean()
            optimizer.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5); optimizer.step()
            running+=loss.item()*len(x)
        val=evaluate(model,data['val'][0],ops)
        row={'epoch':epoch,'train_negative_elbo':running/len(x_train),**{'val_'+k:v for k,v in val.items()}}
        history.append(row)
        if val['negative_elbo_nats_per_image']<best:
            best=val['negative_elbo_nats_per_image']; best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}; best_epoch=epoch
        print(f'Epoch {epoch:02d}: train nELBO={row["train_negative_elbo"]:.2f}; val nELBO={best if best_epoch==epoch else val["negative_elbo_nats_per_image"]:.2f}',flush=True)
    model.load_state_dict(best_state); model.eval()
    elapsed=time.perf_counter()-start
    test=evaluate(model,data['test'][0],ops,samples=16,seed=862)
    result={'seed':SEED,'epochs_run':epochs,'selected_epoch':best_epoch,'latent_dim':latent_dim,
            'training_images':len(x_train),'validation_images':len(data['val'][0]),'test_images':len(data['test'][0]),
            'device':str(device),'threads':torch.get_num_threads(),'torch_version':torch.__version__,
            'training_and_validation_seconds':elapsed,'initial_validation':initial,'best_validation_negative_elbo':best,'test':test,
            'metric_note':'Monte Carlo negative ELBO, not exact negative log likelihood; sum pixels/latents, mean images.'}
    checkpoint={'state_dict':best_state,'latent_dim':latent_dim,'seed':SEED,'selected_epoch':best_epoch}
    torch.save(checkpoint,outdir/'vae_checkpoint.pt')
    (outdir/'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    with (outdir/'training.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=history[0].keys()); writer.writeheader(); writer.writerows(history)
    fig,ax=plt.subplots(figsize=(6.2,4)); ax.plot([r['epoch'] for r in history],[r['train_negative_elbo'] for r in history],label='Training (during updates)')
    ax.plot([r['epoch'] for r in history],[r['val_negative_elbo_nats_per_image'] for r in history],label='Validation (fixed MC noise)')
    ax.set(xlabel='Epoch',ylabel='Negative ELBO [nats / image]',title='A consistent per-image training objective'); ax.legend(); fig.tight_layout()
    fig.savefig(outdir/'learning_curve.png',dpi=170); plt.close(fig)
    visual_report(model,data,outdir)
    return model,result

def load_model(checkpoint=None,device='cpu'):
    path=Path(checkpoint or ROOT/'checkpoints'/'vae_mnist.pt')
    if not path.exists(): raise FileNotFoundError(f'Missing {path}. Train Lab B first or use the supplied checkpoint.')
    state=torch.load(path,map_location='cpu',weights_only=True)
    model=ConvVAE(state['latent_dim']); model.load_state_dict(state['state_dict']); model.to(device).eval()
    return model
