"""Instructor reference implementations. Student notebooks contain TODO versions."""
import torch
import torch.nn.functional as F

def sample_latent(mu,logvar,eps=None):
    if eps is None: eps=torch.randn_like(mu)
    return mu+torch.exp(0.5*logvar)*eps

def kl_diag(mu,logvar):
    """Return one KL per image; sum over latent dimensions only."""
    return 0.5*(mu.square()+logvar.exp()-1-logvar).sum(dim=-1)

def per_image_bce(logits,targets):
    return F.binary_cross_entropy_with_logits(logits,targets,reduction='none').flatten(1).sum(1)

def masked_bce(logits,targets,observed_mask):
    """1 = observed. Keep a SUM of observed pixel NLLs (no division by count)."""
    raw=F.binary_cross_entropy_with_logits(logits,targets,reduction='none')
    return (raw*observed_mask).flatten(1).sum(1)
