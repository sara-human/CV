"""Build the reproducible binary MNIST teaching subset (no torchvision needed)."""
from pathlib import Path
import gzip, hashlib, json, struct, urllib.request
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
RESOURCES={
 'train-images-idx3-ubyte.gz':'f68b3c2dcbeaaa9fbdd348bbdeb94873',
 'train-labels-idx1-ubyte.gz':'d53e105ee54ea40749a09fcbcd1e9432',
 't10k-images-idx3-ubyte.gz':'9fb629c4189551a2d022fa330f9573f3',
 't10k-labels-idx1-ubyte.gz':'ec29112dd5afa0611ce80d1b7f02629c'}
BASE='https://ossci-datasets.s3.amazonaws.com/mnist/'

def prepare(cache=None):
    data=ROOT/'data'; data.mkdir(exist_ok=True)
    cache=Path(cache) if cache else data/'raw'
    cache.mkdir(parents=True,exist_ok=True)
    arrays={}
    for name,md5 in RESOURCES.items():
        dest=cache/name
        if not dest.exists():
            print('Downloading '+name,flush=True)
            with urllib.request.urlopen(BASE+name,timeout=90) as response:
                dest.write_bytes(response.read())
        raw=dest.read_bytes()
        if hashlib.md5(raw).hexdigest()!=md5:
            raise ValueError(f'Checksum mismatch: {dest}; remove this file and rerun.')
        raw=gzip.decompress(raw)
        magic,count=struct.unpack('>II',raw[:8])
        if magic==2051:
            _,_,h,w=struct.unpack('>IIII',raw[:16])
            value=np.frombuffer(raw,dtype=np.uint8,offset=16).reshape(count,h,w)
        elif magic==2049:
            value=np.frombuffer(raw,dtype=np.uint8,offset=8)
        else: raise ValueError('Unexpected IDX magic number')
        arrays[name.split('-idx')[0]]=value
    rng=np.random.default_rng(4186)
    train_ids=[]; val_ids=[]; test_ids=[]
    for digit in range(10):
        ids=rng.permutation(np.flatnonzero(arrays['train-labels']==digit))
        train_ids.extend(ids[:500]); val_ids.extend(ids[500:600])
        ids=rng.permutation(np.flatnonzero(arrays['t10k-labels']==digit))
        test_ids.extend(ids[:100])
    result={}
    for split,ids,prefix in [('train',train_ids,'train'),('val',val_ids,'train'),('test',test_ids,'t10k')]:
        ids=rng.permutation(np.array(ids,dtype=np.int64))
        result['x_'+split]=(arrays[prefix+'-images'][ids]>127).astype(np.uint8)
        result['y_'+split]=arrays[prefix+'-labels'][ids]
        result['source_ids_'+split]=ids
    assert not set(result['source_ids_train']) & set(result['source_ids_val'])
    target=data/'mnist_binary_subset.npz'
    np.savez_compressed(target,**result)
    info={'dataset':'MNIST, fixed threshold >127 (binary pixels, not raw grayscale)',
          'source':BASE,'resource_md5':RESOURCES,'seed':4186,
          'train':5000,'validation':1000,'test':1000,
          'split_rule':'train/validation are disjoint subsets of official train; test uses official t10k',
          'labels':'Used for stratified subset construction and visual analysis only; never VAE targets.',
          'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    (data/'provenance.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
    print(json.dumps(info,indent=2),flush=True)
    return target

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('--cache',type=Path)
    prepare(p.parse_args().cache)
