"""Instructor reproducibility entry point; outputs are local to this package."""
from pathlib import Path
import argparse,json,shutil
import solutions
from vision_lab import ROOT,train_vae
import lab_a,lab_c

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--epochs',type=int,default=12)
    p.add_argument('--device',default='cpu')
    p.add_argument('--steps',type=int,default=100)
    args=p.parse_args()
    a=lab_a.run(solutions)
    model,b=train_vae(solutions,epochs=args.epochs,device=args.device)
    (ROOT/'checkpoints').mkdir(exist_ok=True)
    shutil.copy2(ROOT/'outputs/lab_b/vae_checkpoint.pt',ROOT/'checkpoints/vae_mnist.pt')
    c=lab_c.run(solutions,steps=args.steps,device=args.device)
    (ROOT/'outputs/run_summary.json').write_text(json.dumps({'lab_a':a,'lab_b':b,'lab_c':c},indent=2),encoding='utf-8')
