# Data used by the tutorial

This package contains a small, fixed-threshold binary subset of **MNIST handwritten digits**, associated with Yann LeCun, Corinna Cortes and Christopher J. C. Burges. It is a teaching subset, not the standard full MNIST evaluation protocol.

Upstream resource mirror: <https://ossci-datasets.s3.amazonaws.com/mnist/>. The four resource names and MD5 checksums follow [Torchvision's MNIST dataset definitions](https://github.com/pytorch/vision/blob/main/torchvision/datasets/mnist.py). Exact checksums, the subset seed and the delivered NPZ SHA256 are in `provenance.json`.

## Preprocessing and splitting

- Original images: 28×28 grayscale uint8 pixels.
- Delivered pixels: uint8 binary values, `original_pixel > 127`.
- Seed: 4186, NumPy's default random generator.
- Training: 500 images per digit from the official training split, total 5,000.
- Validation: another 100 images per digit from the official training split, total 1,000; source indices are disjoint from the tutorial training split.
- Test: 100 images per digit from the official test split, total 1,000.

The NPZ contains `x_train`, `y_train`, `source_ids_train`, and analogous `val` and `test` arrays. Source IDs refer to their respective upstream split; numerical overlap between test IDs and training IDs does not imply the same source images. Training and validation IDs refer to the same upstream split and are disjoint.

Labels construct the balanced subset and color analysis plots. They are never targets for the VAE's unsupervised image objective. Validation selects the trained checkpoint; test images are then used for evaluation. Local completion uses the first 12 fixed test images and evaluates their hidden pixels only after inference.

The data are already present. To reconstruct the subset when necessary, run `python coding/prepare_data.py` from the package root with internet access. The script validates upstream archives before processing them. This small preprocessing script does not require Torchvision.
