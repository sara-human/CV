# Tutorial 08 — Student materials

**CS4186 / CS5187 · 30 minutes written + 30 minutes coding.**

1. Use `handouts/Tutorial_08_Student_Handout.pdf` for the four written exercises and your working. An editable DOCX is also provided.
2. For the classroom practical, open **`notebooks/student/00_30min_Coding_Core.ipynb`**. Complete four short functions across three activities: reparameterization (8 min), image ELBO (12 min), and missing-region inference (10 min).
3. The separate notebooks 01–03 are optional extensions after class. The core session uses a supplied model: there is no need to train it during class.

## Install before the lesson

Python 3.12 is recommended. Extract the complete student ZIP and open PowerShell in the extracted `Tutorial_08_CV_Latent_Models` folder:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install torch==2.9.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m jupyter lab
```

On macOS/Linux, use `python3 -m venv .venv` and `.venv/bin/python`; install a PyTorch distribution appropriate to your platform. The practical uses CPU operations.

Open the core notebook and run cells in order. Keep the `coding`, `data` and `checkpoints` folders in place. The small data subset and checkpoint are already included, so the lesson needs no dataset downloads. The notebook's `NotImplementedError` messages identify functions you are meant to complete.

You can alternatively implement the four functions in `coding/student_ops.py` and call them from Python. The notebook functions and that file are separate copies: editing one does not update the other.

## What to hand in

- The four completed functions.
- A brief gradient observation and the per-image ELBO terms.
- A reconstruction versus prior-generation comparison.
- An image-completion grid with missing-pixel scores and one failure analysis.

Use your own explanations for the three exit questions in the notebook. Keep hidden pixel values out of the completion objective. The digit labels are for analysis, not classification targets.

Dataset provenance and preprocessing are documented in `data/README.md`. Generated plots will be saved under `outputs/` when you run the notebooks.
