# Tutorial 08 — Latent models for computer vision

**CS4186 / CS5187 · 60 minutes: 30 minutes written exercises + 30 minutes coding.**

The classroom route connects a pixel likelihood to reparameterization, amortized inference and missing-region completion. It uses four written exercises and one short coding notebook with four functions to complete. The English handout has space for written answers. The supplied data and trained model make the classroom experiments runnable on a CPU without downloads or training during the lesson.

## Open these files

| Use | File |
|---|---|
| Teach from the slides, including worked answers | `slides/Tutorial_08_CV_60min_Lecturer.pptx` or its PDF |
| Print or distribute the student questions | `handouts/Tutorial_08_Student_Handout.pdf` (8 pages, editable DOCX also included) |
| Read solutions, marking notes and lecture alignment | `handouts/Tutorial_08_Instructor_Guide.pdf` (9 pages, editable DOCX also included) |
| Run the 30-minute classroom coding session | `notebooks/student/00_30min_Coding_Core.ipynb` |
| See executed reference code and outputs | `notebooks/instructor/00_30min_Coding_Core_Solutions.ipynb` |
| Extend the practical after class | Standalone notebooks `01`, `02`, `03` |
| Quick instructions in Chinese | `使用说明.txt` |

The lecturer slides and instructor notebooks contain answers. Distribute the separate **Student_Bundle.zip**, not the complete package, when students should work independently. The two course codes share the same tutorial content.

## Pacing

| Minute | Activity | Focus |
|---|---|---|
| 0–7 | Written 1 | Bernoulli pixels, Gaussian KL, and loss reduction |
| 7–15 | Written 2 | Gradients through a sampled visual feature |
| 15–22 | Written 3 | Encoder cost, approximation gap and amortization gap |
| 22–30 | Written 4 | An observed-data ELBO for image completion |
| 30–38 | Coding A | Implement reparameterization; inspect encoder and decoder gradients |
| 38–50 | Coding B | Implement per-image KL and reconstruction loss; compare reconstruction and generation |
| 50–60 | Coding C | Implement observed-pixel loss; refine a local posterior with a frozen decoder |

Each written slot includes a short solution discussion. Fold the three exit-check questions into the final two minutes of Coding C. If students get stuck, reveal the corresponding solution cell and continue to interpretation. Notebooks 01–03 are optional longer practicals, not additional work inside the hour.

## Prepare the environment before class

Python **3.12** is recommended; reference execution used Python 3.12.10 and PyTorch 2.9.1+cpu. Open a PowerShell terminal in this extracted folder and run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install torch==2.9.1 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m jupyter lab
```

On macOS/Linux, use `python3 -m venv .venv`, then `.venv/bin/python` for the remaining commands; install PyTorch using its platform-appropriate distribution. The exercises themselves use CPU operations.

Open `notebooks/student/00_30min_Coding_Core.ipynb` and select the environment's Python kernel. Run cells in order. Keep `coding`, `data` and `checkpoints` together under this folder: notebooks locate their root by walking up from their working directory. No dataset download is required after extraction. A deliberate `NotImplementedError` marks a student TODO; it is not a failed installation.

The four notebook functions are `sample_latent`, `kl_diag`, `per_image_bce` and `masked_bce`. Students can instead implement the same functions in `coding/student_ops.py` for script-based work. These are alternative entry points; editing one does not update the other automatically.

## Teacher checks and reproducibility

From the package root, using the prepared Python environment:

```powershell
.\.venv\Scripts\python.exe coding/check_implementation.py --module solutions
.\.venv\Scripts\python.exe coding/run_all.py --epochs 30 --steps 100
```

The first command checks gradients, KL, reduction axes, masking invariance, data values, model shapes and written calculations. The second regenerates the reference experiments and replaces the generated checkpoint and outputs. To check a completed script submission, use `--module student_ops` on the first command.

The supplied checkpoint was trained for 30 epochs; the selected epoch is the one with the best validation objective. Training uses 5,000 binary MNIST images, validation uses 1,000 disjoint official-training images, and the held-out test subset has 1,000 images. Subsets are balanced by digit with seed 4186. Digit labels are used for subset construction and visual analysis, never as VAE training targets. See `data/README.md` and `data/provenance.json`.

Reference results from the bundled checkpoint:

| Quantity | Observed value |
|---|---:|
| Fixed-noise finite-difference maximum absolute error | 1.47 × 10^-9 |
| Test reconstruction NLL | 104.510 nats/image |
| Test analytic KL | 14.457 nats/image |
| Test Monte Carlo negative ELBO | 118.967 nats/image |
| Missing-pixel BCE: training-pixel-mean baseline | 0.6399 |
| Missing-pixel BCE: encoder initialization | 0.6990 |
| Missing-pixel BCE: local variational refinement | 0.5685 |

Completion scores use the first 12 fixed test images and a central 12×12 mask. The figures display the first eight of those images. These are small teaching experiments, not benchmark claims. Reference results and their full precision are in `outputs/run_summary.json`; validation evidence is in `verification/`.

All four instructor notebooks were executed in a real Jupyter kernel on CPU, including the classroom notebook. Student notebooks intentionally stop at their TODOs. PDF text boundaries and slide element boundaries were checked, and rendered layouts were inspected. DOCX/PPTX remain editable; the supplied PDFs give the intended printed/projected layout.

## Interpretation rules to teach explicitly

- Sum pixel terms and latent dimensions separately; add them per image, then average the batch. Pixel-mean BCE and latent-mean KL change their relative weight.
- The numerical objective is a Monte Carlo estimate of negative ELBO, not exact marginal negative log likelihood.
- Decoder probability images, Bernoulli image draws and input-conditioned reconstructions are different outputs.
- In completion, pass only the observed image and its mask to inference. Original hidden pixels are used afterward for evaluation, never for optimization or selecting the local inference checkpoint.
- Local inference changes the variational distribution with the decoder fixed. It can improve the inference objective without changing the learned generative model.
- A gray-filled encoder input is only an initialization heuristic. A diagonal Gaussian can miss distinct explanations; a predictive mean can look blurred. Better observed fit does not guarantee correct hidden pixels.

## Lecture and implementation references

The instructor guide maps the exercises to the supplied lecture slides: `cs5187_lecture4.pptx` (likelihood/KL/Monte Carlo foundations), `cs5187_lecture5.pptx` (latent models and ELBO), and `CS4186_Latent_Varaible_Model_02.pptx` (reparameterization, amortization and autoencoder interpretation). Exercises use new image-oriented settings instead of repeating the existing coin-MLE or scalar importance-sampling questions.

- Kingma & Welling, [Auto-Encoding Variational Bayes](https://arxiv.org/abs/1312.6114).
- PyTorch [distributions: sample and rsample](https://docs.pytorch.org/docs/stable/distributions.html).
- PyTorch [binary_cross_entropy_with_logits](https://docs.pytorch.org/docs/stable/generated/torch.nn.functional.binary_cross_entropy_with_logits.html).
- Torchvision [MNIST resource definitions and checksums](https://github.com/pytorch/vision/blob/main/torchvision/datasets/mnist.py).
